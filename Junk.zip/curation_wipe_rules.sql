WITH 
	product_curated AS (
		SELECT
			product_id
			,external_id
			,name
			,value
			,brand_standard_field
			,product_name
			,description
		FROM curated_product_fields
		INNER JOIN (
			SELECT
				id AS product_id
				,external_id
				,brand AS brand_standard_field
				,name AS product_name
				,description
			FROM products
			WHERE customer_id = {customer_id}
			AND active = True
			) AS product 
			USING(product_id)
		WHERE customer_id = {customer_id}
		AND LOWER(name) = REGEXP_REPLACE(LOWER('{attribute}'),' ','_','g')
		AND ( EXISTS (
			SELECT
				id
			FROM curation_tasks
			WHERE curation_task_id = curation_tasks.id
			AND resolution = {resolution}
			AND customer_id = {customer_id}
			AND type = 'curation'
			) -- OR curation_task_id IS NULL
			)
	)
	
	SELECT DISTINCT
		external_id
		--,product_name
		,'' AS "Q:{attribute}"
	FROM product_curated